class PDFUtils:
    @staticmethod
    def extract_pages(path):
        return []