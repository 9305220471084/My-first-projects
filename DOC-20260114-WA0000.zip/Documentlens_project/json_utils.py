def validate_json(data):
    return True