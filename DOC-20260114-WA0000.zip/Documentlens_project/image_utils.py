def encode_image(path):
    return None