def run_inference(prompt):
    return {}