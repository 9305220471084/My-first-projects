# DocumentLens – Structured Parser

This project extracts text, tables, and charts from PDF documents using Llama models.

## Usage
python src/structured_extraction.py document.pdf text,tables